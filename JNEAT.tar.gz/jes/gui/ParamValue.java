   package gui;

/**
 * Insert the type's description here.
 * Creation date: (27/03/2002 8.19.10)
 * @author: Administrator
 */
	public class ParamValue {
   
	  public Object o1;
	  public Object o2;
   
   /**
   * ParamValue constructor comment.
   */
	   public ParamValue() {
		 super();
	  }
   
	   public ParamValue(Object _o1, Object _o2) {
		 o1 = _o1;
		 o2 = _o2;
	  
	  }
   
   
   
   }